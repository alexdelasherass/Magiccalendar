package com.alexdelasheras.magia

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("data", MODE_PRIVATE) }
    private val white = Color.rgb(245,245,245)
    private val gray = Color.rgb(165,165,165)
    private val card = Color.rgb(25,25,25)
    private val black = Color.rgb(8,8,8)
    private val line = Color.rgb(55,55,55)
    private val accent = Color.rgb(225,225,225)
    private val dateFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val isoFmt = DateTimeFormatter.ISO_LOCAL_DATE
    private var selectedDate: LocalDate = LocalDate.now()
    private var calendarMonth: YearMonth = YearMonth.now()
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannel(this)
        showHome()
    }

    private fun allShows(): JSONArray = JSONArray(prefs.getString("shows", "[]"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(black)
        setPadding(dp(18), dp(18), dp(18), dp(10))
    }

    private fun text(s: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun title(s: String): TextView = text(s, 28f, white, true).apply {
        setPadding(0, dp(4), 0, dp(14))
    }

    private fun button(s: String, onClick: () -> Unit): TextView = text(s, 15f, white, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(13), dp(12), dp(13))
        setBackgroundColor(card)
        setOnClickListener { onClick() }
    }

    private fun cardView(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        setBackgroundColor(card)
    }

    private fun setScreen(body: LinearLayout, active: String) {
        val scroll = ScrollView(this).apply { addView(body) }
        val frame = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(black) }
        frame.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        frame.addView(navBar(active), LinearLayout.LayoutParams(-1, dp(64)))
        setContentView(frame)
    }

    private fun navBar(active: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setBackgroundColor(Color.rgb(15,15,15))
        val items = listOf("⌂\nInicio" to "home", "▦\nCalendario" to "calendar", "✦\nShows" to "shows", "♙\nClientes" to "clients", "◈\nStats" to "stats")
        items.forEach { (label, key) ->
            val v = text(label, 11f, if (key == active) white else gray, key == active).apply {
                gravity = Gravity.CENTER
                setOnClickListener {
                    when(key) { "home" -> showHome(); "calendar" -> showCalendar(); "shows" -> showShows(); "clients" -> showClients(); else -> showStats() }
                }
            }
            addView(v, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun showHome() {
        val body = root()
        body.addView(title("ALEX MAGIA"))
        body.addView(text("GESTIÓN DE ESPECTÁCULOS", 12f, gray, true), LinearLayout.LayoutParams(-1, dp(24)))

        val shows = allShows()
        val today = LocalDate.now()
        val upcoming = mutableListOf<JSONObject>()
        for (i in 0 until shows.length()) {
            val o = shows.getJSONObject(i)
            parseDate(o.optString("date"))?.let { if (!it.isBefore(today)) upcoming.add(o) }
        }
        upcoming.sortBy { parseDate(it.optString("date")) }

        val next = cardView()
        next.addView(text("PRÓXIMO ESPECTÁCULO", 12f, gray, true))
        if (upcoming.isEmpty()) {
            next.addView(text("No tienes espectáculos próximos.", 19f, white, true).apply { setPadding(0, dp(10), 0, 0) })
        } else {
            val o = upcoming.first()
            next.addView(text("🎩  ${o.optString("title", "Espectáculo")}", 21f, white, true).apply { setPadding(0, dp(8), 0, 0) })
            next.addView(text("${o.optString("date")}  ·  ${o.optString("time", "")}", 15f, white).apply { setPadding(0, dp(5), 0, 0) })
            next.addView(text("${o.optString("client", "")}  ·  ${o.optString("place", "")}", 14f, gray).apply { setPadding(0, dp(4), 0, 0) })
        }
        body.addView(next, marginParams(0,0,0,14))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("＋\nNUEVO SHOW") { showForm(-1) }, LinearLayout.LayoutParams(0, dp(70), 1f).also { it.setMargins(0,0,dp(6),0) })
        actions.addView(button("▦\nCALENDARIO") { showCalendar() }, LinearLayout.LayoutParams(0, dp(70), 1f).also { it.setMargins(dp(6),0,0,0) })
        body.addView(actions, marginParams(0,0,0,14))

        val week = cardView()
        week.addView(text("ESTA SEMANA", 12f, gray, true))
        val end = today.plusDays(7)
        val count = upcoming.count { parseDate(it.optString("date"))?.let { d -> !d.isBefore(today) && d.isBefore(end) } == true }
        week.addView(text("$count espectáculo${if (count == 1) "" else "s"} programado${if (count == 1) "" else "s"}", 20f, white, true).apply { setPadding(0, dp(8), 0, 0) })
        body.addView(week)

        val upcomingTitle = text("PRÓXIMOS", 12f, gray, true).apply { setPadding(0, dp(20),0,dp(8)) }
        body.addView(upcomingTitle)
        upcoming.take(4).forEach { o -> body.addView(showRow(o) { showForm(indexOfId(o.optString("id"))) }, marginParams(0,0,0,7)) }
        if (upcoming.isEmpty()) body.addView(text("Añade tu primer espectáculo desde el botón Nuevo Show.", 15f, gray))
        setScreen(body, "home")
    }

    private fun showRow(o: JSONObject, click: () -> Unit): View {
        val c = cardView().apply { setOnClickListener { click() } }
        c.addView(text("${o.optString("date")}   ${o.optString("time", "")}", 12f, gray, true))
        c.addView(text(o.optString("title", "Espectáculo"), 18f, white, true).apply { setPadding(0, dp(5),0,0) })
        c.addView(text("${o.optString("client", "Sin cliente")} · ${o.optString("place", "Sin lugar")}", 13f, gray).apply { setPadding(0,dp(3),0,0) })
        return c
    }

    private fun showCalendar() {
        val body = root()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val t = title("CALENDARIO"); header.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("＋", { showForm(-1) }).apply { textSize=24f }, LinearLayout.LayoutParams(dp(55), dp(50)))
        body.addView(header)

        val monthBar = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(0,0,0,dp(10)) }
        monthBar.addView(button("‹") { calendarMonth = calendarMonth.minusMonths(1); showCalendar() }, LinearLayout.LayoutParams(dp(55),dp(50)))
        monthBar.addView(text(calendarMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale("es","ES"))).uppercase(Locale("es","ES")),18f,white,true).apply{gravity=Gravity.CENTER}, LinearLayout.LayoutParams(0,dp(50),1f))
        monthBar.addView(button("›") { calendarMonth = calendarMonth.plusMonths(1); showCalendar() }, LinearLayout.LayoutParams(dp(55),dp(50)))
        body.addView(monthBar)

        val grid = GridLayout(this).apply { columnCount=7; rowCount=7; setBackgroundColor(line) }
        listOf("L","M","X","J","V","S","D").forEach { d -> grid.addView(text(d,12f,gray,true).apply{gravity=Gravity.CENTER;setBackgroundColor(black)}, gridParams()) }
        val first = calendarMonth.atDay(1)
        val offset = first.dayOfWeek.value - 1
        val days = calendarMonth.lengthOfMonth()
        val showMap = HashMap<LocalDate,Int>()
        val a=allShows(); for(i in 0 until a.length()){ parseDate(a.getJSONObject(i).optString("date"))?.let{showMap[it]=(showMap[it]?:0)+1} }
        repeat(offset) { grid.addView(View(this).apply{setBackgroundColor(black)}, gridParams()) }
        for(day in 1..days) {
            val date=calendarMonth.atDay(day); val n=showMap[date]?:0
            val cell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(2,dp(7),2,dp(5));setBackgroundColor(if(date==selectedDate) Color.rgb(45,45,45) else black);setOnClickListener{selectedDate=date;showCalendar()}}
            cell.addView(text(day.toString(),15f,if(date==LocalDate.now()) white else gray,date==LocalDate.now()).apply{gravity=Gravity.CENTER})
            cell.addView(text(if(n>0) "•".repeat(minOf(n,3)) else "",12f,white,true).apply{gravity=Gravity.CENTER})
            grid.addView(cell,gridParams())
        }
        body.addView(grid, marginParams(0,0,0,14))
        body.addView(text("${selectedDate.format(dateFmt)} · ESPECTÁCULOS", 13f, gray, true).apply{setPadding(0,dp(4),0,dp(8))})
        var found=false
        for(i in 0 until a.length()) { val o=a.getJSONObject(i); if(parseDate(o.optString("date"))==selectedDate){ body.addView(showRow(o){showForm(i)},marginParams(0,0,0,7));found=true } }
        if(!found) body.addView(text("No hay espectáculos este día.",16f,gray).apply{setPadding(0,dp(8),0,0)})
        setScreen(body,"calendar")
    }

    private fun showShows() {
        val body=root(); body.addView(title("ESPECTÁCULOS"))
        body.addView(button("＋  NUEVO ESPECTÁCULO") { showForm(-1) }, marginParams(0,0,0,12))
        val a=allShows(); val list=(0 until a.length()).map{a.getJSONObject(it) to it}.sortedBy{parseDate(it.first.optString("date")) ?: LocalDate.MAX}
        if(list.isEmpty()) body.addView(text("No hay espectáculos todavía.",16f,gray))
        list.forEach{(o,i)->body.addView(showRow(o){showForm(i)},marginParams(0,0,0,7))}
        setScreen(body,"shows")
    }

    private fun showClients() {
        val body=root(); body.addView(title("CLIENTES"))
        val a=allShows(); val map=LinkedHashMap<String,MutableList<Int>>()
        for(i in 0 until a.length()){val o=a.getJSONObject(i);val c=o.optString("client").trim();if(c.isNotEmpty())map.getOrPut(c){mutableListOf()}.add(i)}
        if(map.isEmpty()) body.addView(text("Los clientes aparecerán aquí cuando guardes espectáculos.",16f,gray))
        map.forEach{(name,idxs)->
            val o=a.getJSONObject(idxs.last()); val c=cardView().apply{setOnClickListener{showClientDetail(name,idxs)}}
            c.addView(text(name,19f,white,true)); c.addView(text("${idxs.size} espectáculo${if(idxs.size==1)"" else "s"} · ${o.optString("phone","")}",13f,gray).apply{setPadding(0,dp(5),0,0)})
            body.addView(c,marginParams(0,0,0,7))
        }
        setScreen(body,"clients")
    }

    private fun showClientDetail(name:String, indexes:List<Int>) {
        val body=root(); body.addView(title(name)); body.addView(text("HISTORIAL",12f,gray,true).apply{setPadding(0,0,0,dp(10))})
        val a=allShows(); indexes.forEach{ i->body.addView(showRow(a.getJSONObject(i)){showForm(i)},marginParams(0,0,0,7)) }
        val phone=a.getJSONObject(indexes.last()).optString("phone","")
        if(phone.isNotBlank()) body.addView(button("☎  LLAMAR $phone"){startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:$phone")))},marginParams(0,dp(10),0,0))
        setScreen(body,"clients")
    }

    private fun showStats() {
        val body=root(); body.addView(title("ESTADÍSTICAS")); val a=allShows(); var total=0.0;var pending=0.0;var paid=0.0
        for(i in 0 until a.length()){val o=a.getJSONObject(i);val p=o.optDouble("price",o.optString("price").replace(",",".").toDoubleOrNull()?:0.0);total+=p;if(o.optBoolean("paid"))paid+=p else pending+=p}
        statCard(body,"ESPECTÁCULOS",a.length().toString()); statCard(body,"INGRESOS REGISTRADOS",money(total)); statCard(body,"COBRADO",money(paid)); statCard(body,"PENDIENTE",money(pending))
        val months=LinkedHashMap<String,Int>(); for(i in 0 until a.length()){parseDate(a.getJSONObject(i).optString("date"))?.let{val k=it.format(DateTimeFormatter.ofPattern("MMM yyyy",Locale("es","ES")));months[k]=(months[k]?:0)+1}}
        body.addView(text("POR MES",12f,gray,true).apply{setPadding(0,dp(20),0,dp(8))}); months.forEach{(m,n)->body.addView(text("$m  ·  $n show${if(n==1)"" else "s"}",16f,white).apply{setPadding(dp(2),dp(8),0,dp(8))})}
        setScreen(body,"stats")
    }

    private fun statCard(body:LinearLayout,label:String,value:String){val c=cardView();c.addView(text(label,11f,gray,true));c.addView(text(value,25f,white,true).apply{setPadding(0,dp(5),0,0)});body.addView(c,marginParams(0,0,0,7))}
    private fun money(v:Double)="%.2f €".format(Locale.US,v)

    private fun showForm(index:Int) {
        val a=allShows(); val old=if(index>=0)a.getJSONObject(index) else JSONObject(); val id=old.optString("id",UUID.randomUUID().toString())
        val body=root(); val heading=title(if(index<0)"NUEVO ESPECTÁCULO" else "EDITAR ESPECTÁCULO");body.addView(heading)
        fun field(label:String,value:String="",inputType:Int=1):EditText=EditText(this).apply{hint=label;setHintTextColor(gray);setTextColor(white);setText(value);textSize=16f;this.inputType=inputType;setPadding(dp(2),dp(10),dp(2),dp(10));setBackgroundColor(Color.TRANSPARENT)}
        val title=field("Nombre del espectáculo",old.optString("title")); val client=field("Cliente / empresa",old.optString("client")); val phone=field("Teléfono",old.optString("phone"),3); val email=field("Email",old.optString("email")); val place=field("Lugar / dirección",old.optString("place")); val price=field("Caché (€)",old.optString("price"),2)
        val notes=field("Notas",old.optString("notes")); notes.minLines=3
        val date=button("📅  Fecha: ${old.optString("date",selectedDate.format(dateFmt))}"){pickDate(date,old.optString("date",selectedDate.format(dateFmt)))}
        val time=button("◷  Hora: ${old.optString("time","20:00")}"){pickTime(time,old.optString("time","20:00"))}
        body.addView(title);body.addView(date,marginParams(0,0,0,5));body.addView(time,marginParams(0,0,0,5));body.addView(client);body.addView(phone);body.addView(email);body.addView(place);body.addView(price)
        val status=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Pendiente","Confirmado","Realizado","Cancelado"));setSelection(listOf("pendiente","confirmado","realizado","cancelado").indexOf(old.optString("status","pendiente")).coerceAtLeast(0))}
        body.addView(text("ESTADO",11f,gray,true).apply{setPadding(0,dp(12),0,dp(4))});body.addView(status)
        val paid=CheckBox(this).apply{text="Cobrado";setTextColor(white);isChecked=old.optBoolean("paid",false)};body.addView(paid)
        val reminder=CheckBox(this).apply{text="Recordarme este espectáculo";setTextColor(white);isChecked=old.optBoolean("reminder",true)};body.addView(reminder)
        val remindHours=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("15 min antes","1 hora antes","2 horas antes","1 día antes"));setSelection(old.optInt("reminderOffset",1).coerceIn(0,3))};body.addView(remindHours)
        body.addView(text("NOTAS",11f,gray,true).apply{setPadding(0,dp(12),0,dp(4))});body.addView(notes)
        val save=button("GUARDAR ESPECTÁCULO"){val d=date.text.toString().removePrefix("📅  Fecha: ");val tm=time.text.toString().removePrefix("◷  Hora: ");val n=JSONObject().apply{put("id",id);put("title",title.text.toString());put("date",d);put("time",tm);put("client",client.text.toString());put("phone",phone.text.toString());put("email",email.text.toString());put("place",place.text.toString());put("price",price.text.toString());put("notes",notes.text.toString());put("status",status.selectedItem.toString().lowercase());put("paid",paid.isChecked);put("reminder",reminder.isChecked);put("reminderOffset",remindHours.selectedItemPosition)};if(index<0)a.put(n)else a.put(index,n);prefs.edit().putString("shows",a.toString()).apply(); if(reminder.isChecked) scheduleReminder(n) else cancelReminder(id); showCalendar()}
        body.addView(save,marginParams(0,dp(15),0,7))
        if(index>=0) body.addView(button("ELIMINAR ESPECTÁCULO"){AlertDialog.Builder(this).setTitle("Eliminar espectáculo").setMessage("¿Seguro que quieres eliminarlo?").setNegativeButton("Cancelar",null).setPositiveButton("Eliminar"){_,_->a.remove(index);prefs.edit().putString("shows",a.toString()).apply();cancelReminder(id);showCalendar()}.show()},marginParams(0,0,0,20))
        body.addView(button("← VOLVER") { showCalendar() })
        setContentView(ScrollView(this).apply{setBackgroundColor(black);addView(body)})
    }

    private fun pickDate(view:TextView,current:String){val d=parseDate(current)?:LocalDate.now();DatePickerDialog(this,{_,y,m,day->view.text="📅  Fecha: ${LocalDate.of(y,m+1,day).format(dateFmt)}"},d.year,d.monthValue-1,d.dayOfMonth).show()}
    private fun pickTime(view:TextView,current:String){val parts=current.split(":");TimePickerDialog(this,{_,h,m->view.text="◷  Hora: %02d:%02d".format(h,m)},parts.getOrNull(0)?.toIntOrNull()?:20,parts.getOrNull(1)?.toIntOrNull()?:0,true).show()}

    private fun parseDate(s:String):LocalDate?=try{LocalDate.parse(s,isoFmt)}catch(_:Exception){try{LocalDate.parse(s,dateFmt)}catch(_:Exception){null}}
    private fun indexOfId(id:String):Int{val a=allShows();for(i in 0 until a.length())if(a.getJSONObject(i).optString("id")==id)return i;return -1}

    private fun scheduleReminder(o:JSONObject){val d=parseDate(o.optString("date"))?:return;val t=o.optString("time","20:00").split(":");val dt=LocalDateTime.of(d,t.getOrNull(0)?.toIntOrNull()?:20,t.getOrNull(1)?.toIntOrNull()?:0);val mins=listOf(15,60,120,1440).getOrElse(o.optInt("reminderOffset",1)){60};val millis=dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()-mins*60_000L;if(millis<=System.currentTimeMillis())return;val intent=Intent(this,ReminderReceiver::class.java).apply{putExtra("id",o.optString("id"));putExtra("title",o.optString("title"));putExtra("date",o.optString("date"));putExtra("time",o.optString("time"));putExtra("place",o.optString("place"))};val pi=PendingIntent.getBroadcast(this,requestCode(o.optString("id")),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);(getSystemService(ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi);if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),44)}
    private fun cancelReminder(id:String){val intent=Intent(this,ReminderReceiver::class.java);val pi=PendingIntent.getBroadcast(this,requestCode(id),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);(getSystemService(ALARM_SERVICE) as AlarmManager).cancel(pi)}
    private fun requestCode(id:String)=id.hashCode() and 0x7fffffff

    private fun marginParams(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(-1,-2).also{it.setMargins(dp(l),dp(t),dp(r),dp(b))}
    private fun gridParams()=GridLayout.LayoutParams().apply{width=0;height=dp(62);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);rowSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(1,1,1,1)}
}

class ReminderReceiver: BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent){NotificationHelper.show(context,intent.getStringExtra("title") ?: "Espectáculo", "${intent.getStringExtra("date") ?: ""} · ${intent.getStringExtra("time") ?: ""} · ${intent.getStringExtra("place") ?: ""}")}}

object NotificationHelper{
    private const val CHANNEL="shows"
    fun createChannel(c:Context){if(android.os.Build.VERSION.SDK_INT>=26){val ch=NotificationChannel(CHANNEL,"Espectáculos",NotificationManager.IMPORTANCE_HIGH);ch.description="Recordatorios de espectáculos";(c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)}}
    fun show(c:Context,title:String,msg:String){val n=androidx.core.app.NotificationCompat.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("🎩 $title").setContentText(msg).setAutoCancel(true).setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH).build();(c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(title.hashCode(),n)}
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("data", Context.MODE_PRIVATE)
        val a = JSONArray(prefs.getString("shows", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optBoolean("reminder", true)) {
                val d = try { LocalDate.parse(o.optString("date"), DateTimeFormatter.ISO_LOCAL_DATE) } catch (_: Exception) {
                    try { LocalDate.parse(o.optString("date"), DateTimeFormatter.ofPattern("dd/MM/yyyy")) } catch (_: Exception) { null }
                } ?: continue
                val parts = o.optString("time", "20:00").split(":")
                val dt = LocalDateTime.of(d, parts.getOrNull(0)?.toIntOrNull() ?: 20, parts.getOrNull(1)?.toIntOrNull() ?: 0)
                val offset = listOf(15, 60, 120, 1440).getOrElse(o.optInt("reminderOffset", 1)) { 60 }
                val millis = dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() - offset * 60_000L
                if (millis <= System.currentTimeMillis()) continue
                val piIntent = Intent(context, ReminderReceiver::class.java).apply {
                    putExtra("id", o.optString("id")); putExtra("title", o.optString("title")); putExtra("date", o.optString("date")); putExtra("time", o.optString("time")); putExtra("place", o.optString("place"))
                }
                val pi = PendingIntent.getBroadcast(context, (o.optString("id").hashCode() and 0x7fffffff), piIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
            }
        }
    }
}
