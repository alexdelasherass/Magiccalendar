# Alex Magia — Android
App inicial para gestionar espectáculos y clientes.

Incluye:
- Agenda/listado de espectáculos
- Alta y edición
- Cliente/empresa
- Teléfono y email
- Fecha y hora
- Lugar/dirección
- Caché
- Notas
- Datos guardados localmente en el teléfono

Para generar el APK necesitas Android Studio y ejecutar:
./gradlew assembleDebug

El APK resultante estará en:
app/build/outputs/apk/debug/app-debug.apk
