package com.alexdelasheras.magia

import android.app.*
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("data", Context.MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) { super.onCreate(b); showHome() }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,35,28,25) }
        val title=TextView(this).apply { text="✨ ALEX MAGIA"; textSize=28f; setTextColor(Color.BLACK); gravity=Gravity.CENTER; setPadding(0,0,0,25) }
        root.addView(title)
        val add=Button(this).apply { text="＋ Nuevo espectáculo"; setOnClickListener{showForm(-1)} }
        root.addView(add)
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(ScrollView(this).apply{addView(list)}, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val a=JSONArray(prefs.getString("shows","[]"))
        if(a.length()==0){ list.addView(TextView(this).apply{text="No hay espectáculos todavía.";textSize=18f;setPadding(10,40,10,10)});return}
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i)
            val card=TextView(this).apply{
                text="🎩 ${o.optString("title","Espectáculo")}\n📅 ${o.optString("date")}  ·  ${o.optString("time")}\n👤 ${o.optString("client")}\n📍 ${o.optString("place")}"
                textSize=17f; setPadding(20,20,20,20); setTextColor(Color.DKGRAY)
                setOnClickListener{showForm(i)}
            }
            list.addView(card)
        }
    }

    private fun showForm(index:Int){
        val a=JSONArray(prefs.getString("shows","[]"))
        val o=if(index>=0)a.getJSONObject(index) else JSONObject()
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,20,30,10)}
        fun field(h:String,v:String=""):EditText=EditText(this).apply{hint=h;setText(v)}
        val title=field("Nombre del espectáculo",o.optString("title"))
        val date=field("Fecha (dd/mm/aaaa)",o.optString("date"))
        val time=field("Hora",o.optString("time"))
        val client=field("Cliente / empresa",o.optString("client"))
        val phone=field("Teléfono",o.optString("phone"))
        val email=field("Email",o.optString("email"))
        val place=field("Lugar / dirección",o.optString("place"))
        val price=field("Precio / caché",o.optString("price"))
        val notes=field("Notas",o.optString("notes"))
        listOf(title,date,time,client,phone,email,place,price,notes).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle(if(index<0)"Nuevo espectáculo" else "Editar espectáculo")
            .setView(ScrollView(this).apply{addView(box)})
            .setPositiveButton("Guardar"){_,_->
                val n=JSONObject().apply{
                    put("title",title.text.toString());put("date",date.text.toString());put("time",time.text.toString())
                    put("client",client.text.toString());put("phone",phone.text.toString());put("email",email.text.toString())
                    put("place",place.text.toString());put("price",price.text.toString());put("notes",notes.text.toString())
                }
                if(index<0)a.put(n) else a.put(index,n)
                prefs.edit().putString("shows",a.toString()).apply();refresh()
            }.setNegativeButton("Cancelar",null).show()
    }
}